package com.example.irctcfill

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        val info = TextView(this).apply {
            text = "One passenger per line as Name|Age\nExample:\nRajesh Patel|45\nMeena Patel|42"
        }
        val box = EditText(this).apply {
            setText(Store.raw(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 6
            gravity = android.view.Gravity.TOP
        }
        val save = Button(this).apply {
            text = "Save passengers"
            setOnClickListener {
                Store.save(this@MainActivity, box.text.toString())
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        val enable = Button(this).apply {
            text = "Turn on accessibility service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        listOf(info, box, save, enable).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
