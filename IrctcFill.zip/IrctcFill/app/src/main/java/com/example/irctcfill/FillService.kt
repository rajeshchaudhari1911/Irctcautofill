package com.example.irctcfill

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.Toast

class FillService : AccessibilityService() {

    private val irctc = "cris.org.in.prs.ima"
    // Adjust these if IRCTC changes its field labels.
    private val nameRx = Regex("\\bname\\b", RegexOption.IGNORE_CASE)
    private val ageRx = Regex("\\bage\\b", RegexOption.IGNORE_CASE)

    private var button: Button? = null
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.packageName?.toString() == irctc) showButton() else hideButton()
    }

    override fun onInterrupt() {}

    override fun onDestroy() { hideButton(); super.onDestroy() }

    private fun showButton() {
        if (button != null) return
        val b = Button(this).apply { text = "Fill"; setOnClickListener { fill() } }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(b, lp)
        button = b
    }

    private fun hideButton() {
        button?.let { runCatching { wm.removeView(it) } }
        button = null
    }

    private fun fill() {
        val list = Store.load(this)
        val root = rootInActiveWindow ?: return
        if (list.isEmpty()) { toast("No passengers saved"); return }

        val names = mutableListOf<AccessibilityNodeInfo>()
        val ages = mutableListOf<AccessibilityNodeInfo>()
        collect(root, names, ages)

        var n = 0
        names.forEachIndexed { i, node -> list.getOrNull(i)?.let { if (setText(node, it.name)) n++ } }
        ages.forEachIndexed { i, node ->
            list.getOrNull(i)?.takeIf { it.age.isNotEmpty() }?.let { if (setText(node, it.age)) n++ }
        }
        toast(if (n == 0) "No empty name/age fields found" else "Filled $n fields")
    }

    private fun collect(node: AccessibilityNodeInfo, names: MutableList<AccessibilityNodeInfo>, ages: MutableList<AccessibilityNodeInfo>) {
        if (node.className?.toString()?.contains("EditText") == true && node.isEditable && isEmpty(node)) {
            val label = listOfNotNull(node.hintText, node.contentDescription, node.viewIdResourceName)
                .joinToString(" ").replace('_', ' ')
            when {
                ageRx.containsMatchIn(label) -> ages.add(node)
                nameRx.containsMatchIn(label) -> names.add(node)
            }
        }
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, names, ages) }
    }

    private fun isEmpty(n: AccessibilityNodeInfo) = n.isShowingHintText || n.text.isNullOrEmpty()

    private fun setText(n: AccessibilityNodeInfo, v: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, v)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
