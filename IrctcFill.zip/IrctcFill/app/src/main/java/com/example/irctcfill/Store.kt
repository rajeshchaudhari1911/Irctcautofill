package com.example.irctcfill

import android.content.Context

data class Passenger(val name: String, val age: String)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)

    // One passenger per line: "Name|Age"
    fun save(c: Context, text: String) = p(c).edit().putString("list", text).apply()
    fun raw(c: Context): String = p(c).getString("list", "") ?: ""

    fun load(c: Context): List<Passenger> = raw(c).lines()
        .map { it.split("|").map(String::trim) }
        .filter { it.isNotEmpty() && it[0].isNotEmpty() }
        .map { Passenger(it[0], it.getOrElse(1) { "" }) }
}
