package com.example.irctcautofill

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var scan: TextView

    private fun field(hint: String, key: String, lines: Int = 1) = EditText(this).apply {
        this.hint = hint
        setText(Store.get(this@MainActivity, key))
        inputType = InputType.TYPE_CLASS_TEXT or (if (lines > 1) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0)
        minLines = lines
        gravity = Gravity.TOP
        tag = key
        importantForAutofill = android.view.View.IMPORTANT_FOR_AUTOFILL_NO
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        val fields = listOf(
            field("From station (as you type it in IRCTC)", "from"),
            field("To station", "to"),
            field("Journey date (as IRCTC shows it, e.g. 20-11-2026)", "date"),
            field("Passengers: one per line as Name|Age", "pax", 5)
        )
        val save = Button(this).apply {
            text = "Save"
            setOnClickListener {
                fields.forEach { Store.put(this@MainActivity, it.tag as String, it.text.toString().trim()) }
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        val enable = Button(this).apply {
            text = "Choose IRCTC Autofill as autofill service"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:$packageName")))
            }
        }
        scan = TextView(this).apply { setPadding(0, pad, 0, 0) }

        fields.forEach { root.addView(it) }
        listOf(save, enable, scan).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val s = Store.get(this, "scan")
        scan.text = if (s.isEmpty()) "Last scan of the IRCTC app: none yet" else "Last scan of the IRCTC app:\n$s"
    }
}
