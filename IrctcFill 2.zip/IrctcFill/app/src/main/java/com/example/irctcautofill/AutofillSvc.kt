package com.example.irctcautofill

import android.app.assist.AssistStructure.ViewNode
import android.os.CancellationSignal
import android.service.autofill.*
import android.view.View
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.RemoteViews

@Suppress("DEPRECATION")
class AutofillSvc : AutofillService() {

    private val irctc = "cris.org.in.prs.ima"
    private val ic = RegexOption.IGNORE_CASE
    // If IRCTC uses other labels, add words here (see "Last scan" in the app).
    private val rxFrom = Regex("from|source|origin|boarding", ic)
    private val rxTo = Regex("\\bto\\b|destination", ic)
    private val rxDate = Regex("\\bdate\\b", ic)
    private val rxAge = Regex("\\bage\\b", ic)
    private val rxName = Regex("\\bname\\b", ic)

    private class Found {
        val from = mutableListOf<AutofillId>()
        val to = mutableListOf<AutofillId>()
        val date = mutableListOf<AutofillId>()
        val name = mutableListOf<AutofillId>()
        val age = mutableListOf<AutofillId>()
        val seen = mutableListOf<String>()
    }

    override fun onFillRequest(req: FillRequest, cancel: CancellationSignal, cb: FillCallback) {
        try {
            val st = req.fillContexts.last().structure
            if (st.activityComponent.packageName != irctc) { cb.onSuccess(null); return }

            val f = Found()
            for (i in 0 until st.windowNodeCount) walk(st.getWindowNodeAt(i).rootViewNode, f)
            Store.put(this, "scan",
                "${f.seen.size} fields seen (from=${f.from.size}, to=${f.to.size}, date=${f.date.size}, " +
                "name=${f.name.size}, age=${f.age.size}):\n" + f.seen.joinToString("\n").take(1500))

            val rb = FillResponse.Builder()
            var n = 0

            // Journey details
            val src = Store.get(this, "from"); val dst = Store.get(this, "to"); val dt = Store.get(this, "date")
            val j = mutableListOf<Pair<AutofillId, String>>()
            if (src.isNotEmpty()) f.from.forEach { j += it to src }
            if (dst.isNotEmpty()) f.to.forEach { j += it to dst }
            if (dt.isNotEmpty()) f.date.forEach { j += it to dt }
            if (j.isNotEmpty()) { rb.addDataset(dataset("Journey: $src → $dst  $dt".trim(), j)); n++ }

            // Passengers: for each name/age slot, offer every saved passenger
            val pax = Store.passengers(this)
            for (k in 0 until maxOf(f.name.size, f.age.size)) for (p in pax) {
                val v = mutableListOf<Pair<AutofillId, String>>()
                f.name.getOrNull(k)?.let { v += it to p.first }
                if (p.second.isNotEmpty()) f.age.getOrNull(k)?.let { v += it to p.second }
                if (v.isNotEmpty()) { rb.addDataset(dataset("${p.first}  ${p.second}".trim(), v)); n++ }
            }
            // All passengers at once: passenger i -> slot i
            if (pax.size > 1) {
                val v = mutableListOf<Pair<AutofillId, String>>()
                pax.forEachIndexed { i, p ->
                    f.name.getOrNull(i)?.let { v += it to p.first }
                    if (p.second.isNotEmpty()) f.age.getOrNull(i)?.let { v += it to p.second }
                }
                if (v.isNotEmpty()) { rb.addDataset(dataset("All ${pax.size} passengers", v)); n++ }
            }

            cb.onSuccess(if (n > 0) rb.build() else null)
        } catch (e: Exception) {
            Store.put(this, "scan", "Error: $e")
            cb.onSuccess(null)
        }
    }

    override fun onSaveRequest(req: SaveRequest, cb: SaveCallback) = cb.onSuccess()

    private fun walk(n: ViewNode, f: Found) {
        val id = n.autofillId
        if (id != null && n.autofillType == View.AUTOFILL_TYPE_TEXT) {
            val label = listOfNotNull(n.hint, n.idEntry, n.contentDescription?.toString(), n.autofillHints?.joinToString(" "))
                .joinToString(" ")
                .replace(Regex("([a-z])([A-Z])"), "$1 $2")
                .replace(Regex("[_.:/\\-]"), " ")
            f.seen += label.ifBlank { "(no label)" }
            when {
                rxFrom.containsMatchIn(label) -> f.from.add(id)
                rxTo.containsMatchIn(label) -> f.to.add(id)
                rxDate.containsMatchIn(label) -> f.date.add(id)
                rxAge.containsMatchIn(label) -> f.age.add(id)
                rxName.containsMatchIn(label) -> f.name.add(id)
            }
        }
        for (i in 0 until n.childCount) walk(n.getChildAt(i), f)
    }

    private fun dataset(label: String, vals: List<Pair<AutofillId, String>>): Dataset {
        val row = RemoteViews(packageName, R.layout.item).apply { setTextViewText(R.id.text1, label) }
        val b = Dataset.Builder(row)
        vals.forEach { b.setValue(it.first, AutofillValue.forText(it.second)) }
        return b.build()
    }
}
