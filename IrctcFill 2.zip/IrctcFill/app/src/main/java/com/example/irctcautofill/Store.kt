package com.example.irctcautofill

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): String = p(c).getString(k, "") ?: ""
    fun put(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()

    // One passenger per line: "Name|Age"  ->  (name, age)
    fun passengers(c: Context): List<Pair<String, String>> = get(c, "pax").lines()
        .map { it.split("|").map(String::trim) }
        .filter { it[0].isNotEmpty() }
        .map { it[0] to it.getOrElse(1) { "" } }
}
